﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MonteCarloMethod
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StartaProgram();
        }


        static bool ProgramLoop;
        static string option;

        static void StartaProgram()
        {
            // Använder en global variabel som loopar så länge variabeln är sann
            ProgramLoop = true;

            while (ProgramLoop == true)
            {
                // Kallar på funktioner
                HuvudMeny();
                Options();
                VäxlaRäkneSätt();

            }
        }

        static void HuvudMeny()
        {
            // Kod för huvudmenyn
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("-------------------------");
            Console.WriteLine("The Monte Carlo Method");
            Console.WriteLine("-------------------------");
            Console.WriteLine(" 1. Use Monte Carlo Method");
            Console.WriteLine(" 2. Quit");
            Console.WriteLine("-------------------------\n");
            Console.ForegroundColor = ConsoleColor.White;

        }

        static void Options()
        {
            // Funktion för val av alternativ (räknesätt)
            Console.Write("<Välj ett heltals alternativ> ");
            Console.ForegroundColor = ConsoleColor.Green;
            option = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.White;

        }
        static void VäxlaRäkneSätt()
        {
            // Funktion som växlar mellan räknesätt
            int validOption;

            int.TryParse(option, out validOption);

            switch (validOption)
            {
                case 1:

                    MonteCarloMethod();

                    Thread.Sleep(3000);

                    break;

                case 2:

                    Avsluta();

                    Thread.Sleep(3000);
                    break;

                default:
                    FelHantering();
                    break;
            }

        }

        static void MonteCarloMethod()
        {
            Console.Clear();
            Console.Write("<Radius of circle> ");
            double r = (double)int.Parse(Console.ReadLine());

            int validPoints = 0;
            int invalidPoints = 0;

            Random random = new Random();

            var watch = new System.Diagnostics.Stopwatch();

            watch.Start();

            for (int i = 0; i < r * r; i++)
            {

                int xCoordinate = random.Next((int)-r, (int)r + 1);
                int yCoordinate = random.Next((int)-r, (int)r + 1);

                double hypotenuse = Math.Sqrt(Math.Pow(xCoordinate, 2) + Math.Pow(yCoordinate, 2));

                if (hypotenuse > r)
                {
                    invalidPoints += 1;

                }
                else if (hypotenuse <= r)
                {
                    validPoints += 1;
                }
            }

            watch.Stop();

            double totalPoints = r * r;

            double pi = (double)validPoints / totalPoints * 4;
            Console.WriteLine("");
            Console.WriteLine($"Execution Time: {watch.ElapsedMilliseconds} ms");
            Console.WriteLine($"Valid Points: {validPoints}");
            Console.WriteLine($"Invalid Points: {invalidPoints}");
            Console.WriteLine($"Total Points: {totalPoints}");
            Console.WriteLine($"Pi: {pi}");


            Console.WriteLine("");
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();

        }

        static void FelHantering()
        {
            // Skriver ut att fel inmatning har skett
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("FEL INMATNING");
            Console.ForegroundColor = ConsoleColor.White;
            Thread.Sleep(2000);
            Console.Clear();

        }
        static void Avsluta()
        {
            // Avslutar programmet efter att text har skrivits ut som säger att programmet avslutas
            for (int i = 0; i < 2; i++)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("PROGRAMMET AVSLUTAS!");
                Thread.Sleep(1000);
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("PROGRAMMET AVSLUTAS!");
                Thread.Sleep(1000);
            }
            // Program loopen av slutas
            ProgramLoop = false;
        }
    }
}
