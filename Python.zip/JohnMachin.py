from decimal import *
import time

n = 1
t = 1
sum1 = 0
sum2 = 0

amountOfTerms = int(input("Amount of terms: "))
startTime = time.time()

for i in range(amountOfTerms):
    sum1 += 1/(n * 5**n) * t
    sum2 += 1/(n * 239**n) * t 
    t = -t
    n += 2

endTime = time.time()
runTime = (endTime - startTime) * 1000

print("Execution time: {} ms".format(runTime))
print("Pi: {}".format(sum1*16-sum2*4))

