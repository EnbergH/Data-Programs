from math import *
import time
from decimal import *

getcontext().prec = 8

n = 1
sum = 0

amountOfTerms = int(input("Amount of terms: "))
startTime = time.time()

for i in range(amountOfTerms):
    sum += 1/(n**2)
    n += 1

endTime = time.time()

runTime = (endTime - startTime) * 1000

print("Execution time: {} ms".format(runTime))
print("Sum of terms: {}".format(sum))
print("Pi: {}".format(sqrt(sum*6)))
