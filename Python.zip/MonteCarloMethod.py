from random import *
from math import *
import time


interval = int(input("Set Square ROOT of total points: "))
startTime = time.time()

total = interval**2
insideCircle = 0
outsideCircle = 0


for i in range(interval**2):
    x_coordinate = random()
    y_coordinate = random()

    hypotenuse = sqrt(x_coordinate**2 + y_coordinate**2)

    if hypotenuse > 1:
        outsideCircle += 1
    elif hypotenuse <= 1:
        insideCircle += 1
    
endTime = time.time()
runTime = (endTime - startTime) * 1000

print("Execution time: {} ms".format(runTime))
print("Points OUTSIDE Circle: {}".format(outsideCircle))
print("Points INSIDE Circle: {}".format(insideCircle))
print("Pi: {}".format(insideCircle/total*4))





