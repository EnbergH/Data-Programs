import turtle
from random import *
from math import *
import time

t = turtle.Turtle()

t

t.penup()
t.goto(0, -200)
t.pendown()
t.circle(200)
t.penup()
t.goto(0,-250)
t.pendown()
t.right(270)
t.goto(0, 250)
t.right(90)
t.penup()
t.goto(-250,0)
t.pendown()
t.goto(250,0)

t.penup()
t.goto(-200,-200)
t.pendown()
t.goto(200,-200)
t.left(90)
t.goto(200,200)
t.left(90)
t.goto(-200, 200)
t.left(90)
t.goto(-200,-200)

t.color("blue")


interval = int(input("Set Square ROOT of total points: "))
startTime = time.time()

total = interval**2
insideCircle = 0
outsideCircle = 0


for i in range(interval**2):
    x_coordinate = uniform(-1,1)
    y_coordinate = uniform(-1,1)

    hypotenuse = sqrt(x_coordinate**2 + y_coordinate**2)

    if hypotenuse > 1:
        outsideCircle += 1
        t.color("red")
    elif hypotenuse <= 1:
        insideCircle += 1
        t.color("blue")

    t.penup()
    t.goto(200*x_coordinate, 200*y_coordinate)
    t.dot()
    
endTime = time.time()
runTime = (endTime - startTime) * 1000

print("Execution time: {} ms".format(runTime))
print("Points OUTSIDE Circle: {}".format(outsideCircle))
print("Points INSIDE Circle: {}".format(insideCircle))
print("Pi: {}".format(insideCircle/total*4))

input("<Press Enter to exit>")



