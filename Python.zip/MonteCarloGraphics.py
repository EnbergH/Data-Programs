import turtle
from random import *
from math import *
import time

t = turtle.Turtle()
# s = turtle.Turtle() Används ifall man vill ha räkning av antalet punkter
t

t.penup()
t.goto(0, -200)
t.pendown()
t.circle(200)
t.penup()
t.goto(0,-250)
t.pendown()
t.right(270)
t.goto(0, 250)
t.right(90)
t.penup()
t.goto(-250,0)
t.pendown()
t.goto(250,0)

t.penup()
t.goto(-200,-200)
t.pendown()
t.goto(200,-200)
t.left(90)
t.goto(200,200)
t.left(90)
t.goto(-200, 200)
t.left(90)
t.goto(-200,-200)

t.color("blue")


points = int(input("Set total points: "))
startTime = time.time()

total = points
insideCircle = 0
outsideCircle = 0

t.penup()
t.setposition(-240, 400)
t.pendown()
t.color("black")
t.write("Antal Punkter: {} ".format(points), move=False, font=('monaco',16,'bold'), align='right')

for i in range(points):
    x_coordinate = uniform(-1,1)
    y_coordinate = uniform(-1,1)

    hypotenuse = sqrt(x_coordinate**2 + y_coordinate**2)

    if hypotenuse > 1:
        outsideCircle += 1
        t.color("red")
    elif hypotenuse <= 1:
        insideCircle += 1
        t.color("blue")

    t.penup()
    t.goto(200*x_coordinate, 200*y_coordinate)
    t.dot()

    # Ta bort kommentarerna för att få räkning av antalet punkter som finns

    # s.penup()
    # s.begin_fill()
    # s.color("white")
    # s.setposition(-250,350)
    # s.pendown()
    # for i in range(4):
    #     s.left(90)
    #     s.forward(250)
    # s.end_fill()
    # s.penup()
    # s.setposition(-240, 400)
    # s.pendown()
    # s.color("black")
    # s.write("Antal Punkter: {} ".format(insideCircle+outsideCircle), move=False, font=('monaco',16,'bold'), align='right')

    
endTime = time.time()
runTime = (endTime - startTime) * 1000

print("Execution time: {} ms".format(runTime))
print("Points OUTSIDE Circle: {}".format(outsideCircle))
print("Points INSIDE Circle: {}".format(insideCircle))
print("Pi: {}".format(insideCircle/total*4))

input("<Press Enter to exit>")



