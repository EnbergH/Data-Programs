﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Euler
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StartaProgram();
        }


        static bool ProgramLoop;
        static string option;

        static void StartaProgram()
        {
            // Använder en global variabel som loopar så länge variabeln är sann
            ProgramLoop = true;

            while (ProgramLoop == true)
            {
                // Kallar på funktioner
                HuvudMeny();
                Options();
                VäxlaRäkneSätt();

            }
        }

        static void HuvudMeny()
        {
            // Kod för huvudmenyn
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("-------------------------");
            Console.WriteLine("The Basel Problem");
            Console.WriteLine("-------------------------");
            Console.WriteLine(" 1. Use Basel problem");
            Console.WriteLine(" 2. Quit");
            Console.WriteLine("-------------------------\n");
            Console.ForegroundColor = ConsoleColor.White;

        }

        static void Options()
        {
            // Funktion för val av alternativ (räknesätt)
            Console.Write("<Choose an option> ");
            Console.ForegroundColor = ConsoleColor.Green;
            option = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.White;

        }
        static void VäxlaRäkneSätt()
        {
            // Funktion som växlar mellan räknesätt
            int validOption;

            int.TryParse(option, out validOption);

            switch (validOption)
            {
                case 1:

                    BaselProblemSeries();

                    Thread.Sleep(700);

                    break;

                case 2:

                    Avsluta();

                    Thread.Sleep(700);
                    break;

                default:
                    FelHantering();
                    break;
            }

        }

        static void BaselProblemSeries()
        {
            Console.Clear();
            Console.WriteLine("Amount of terms in the Basel Problem series: ");
            int amountOfTerms = int.Parse(Console.ReadLine());

            var watch = new System.Diagnostics.Stopwatch();
            watch.Start();

            double series = 0;
            double n = 1;

            for (int i = 0; i < amountOfTerms; i++)
            {

                series += 1 / (n*n);
                n += 1;

            }

            double approximation_pi = Math.Sqrt(6 * series);

            watch.Stop();

            Console.WriteLine("");
            Console.WriteLine($"Execution Time: {watch.ElapsedMilliseconds} ms");
            Console.WriteLine($"Pi: {approximation_pi}");


            Console.WriteLine("");
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();

        }

        static void FelHantering()
        {
            // Skriver ut att fel inmatning har skett
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("FEL INMATNING");
            Console.ForegroundColor = ConsoleColor.White;
            Thread.Sleep(2000);
            Console.Clear();

        }
        static void Avsluta()
        {
            // Avslutar programmet efter att text har skrivits ut som säger att programmet avslutas
            for (int i = 0; i < 2; i++)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("PROGRAMMET AVSLUTAS!");
                Thread.Sleep(1000);
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("PROGRAMMET AVSLUTAS!");
                Thread.Sleep(1000);
            }
            // Program loopen avslutas
            ProgramLoop = false;
        }
    }
}

